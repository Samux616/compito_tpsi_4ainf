#include<stdio.h>


#define TRACE() printf("%s %d %s\n", __FILE__, __LINE__, __func__)
