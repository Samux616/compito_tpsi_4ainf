int somma(int, int);
int differenza(int, int);
int moltiplicazione(int, int);
float divisione(float, float);
