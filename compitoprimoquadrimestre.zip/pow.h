int potenza(int, int);
