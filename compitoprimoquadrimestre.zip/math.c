#include"trace.h"
#include<stdio.h>

        int somma(int n1, int n2){
		TRACE();
                int som=0;
                printf("Inserisci un numero:\n");
                scanf ("%d",&n1);
                printf ("Inserisci un numero:\n");
                scanf ("%d",&n2);
                som=n1+n2;
                printf("%d+%d= %d\n",n1, n2, som);
                return som;
        }

	
        int differenza(int n1, int n2){
		TRACE();
                int diff=0;
                printf ("Inserisci un numero:\n");
                scanf ("%d",&n1);
                printf ("Inserisci un numero:\n");
                scanf ("%d",&n2);
                diff=n1-n2;
                printf ("%d-%d=%d\n", n1, n2,diff);
                return diff;
        }
        int moltiplicazione(int n1, int n2){
		TRACE();
                int ris=0;
                printf ("Inserisci un numero:\n");
                scanf ("%d",&n1);
                printf ("Inserisci un numero:\n");
                scanf ("%d",&n2);
                ris=n1*n2;
                printf ("%d*%d=%d\n",n1, n2, ris);
                return ris;
        }
        float divisione(float n1, float n2){
		TRACE();
                float div=0;
                printf ("Inserisci un numero:\n");
                scanf ("%f",&n1);
                printf ("Inserisci un numero:\n");
                scanf ("%f",&n2);
                div=n1/n2;
                printf ("%f:%f=%.2f\n",n1, n2, div);
                return div;
        }
