#include <stdio.h>
#include "math.h"

int main(){
	int op1, op2, ris;	
	char scelta;
	while(1){
		printf("inserisci la scelta tra +, *, -, /, ^, #, !(per uscire) :\n");
		printf("+ Somma\n");
		printf("* Moltiplicazione\n");
		printf("- Differenza\n");
		printf("/ Divisione\n");
		printf("^ Potenza\n");
		printf("# Logger\n");
		printf("! Esci\n");

		scanf(" %c", &scelta);

		if(scelta == '!') return 0;

		switch(scelta){
			case '+':
				ris = somma(op1, op2);
				break;

			case '-':
				ris = differenza(op1, op2);
				break;

			case '*':
				ris = moltiplicazione(op1, op2);
				break;

			case '/':
				ris = divisione(op1, op2);
				break;
				
			case '^':
				ris = potenza(base, esponente);
				break;

			default:
				printf("Operazione non trovata\n");

		}
	}
}	
	

